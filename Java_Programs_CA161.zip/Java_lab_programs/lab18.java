import pack.*;
class lab18
{
 public static void main(String args[])
  {
    pack.lab118 p=new pack.lab118();
    p.display();
  }
}